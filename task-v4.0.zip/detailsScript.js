import db from "./assets/customJs/db.js";
import translations from "./assets/customJs/i18n.js";

function applyTranslations(lang) {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    el.textContent = translations[lang][key];
  });

  if (lang === "ar") {
    document.body.setAttribute("dir", "rtl");
    document.body.classList.add("rtl");
  } else {
    document.body.setAttribute("dir", "ltr");
    document.body.classList.remove("rtl");
  }
}

function getCookie(name) {
  return document.cookie
    .split(";")
    .find((row) => row.startsWith(name + "="))
    ?.split("=")[1];
}

const params = new URLSearchParams(window.location.search);
const id = Number(params.get("id"));
let lang = getCookie("lang") || "en";
const employee = db.getById(id);

$("#langSelect").val(lang);
applyTranslations(lang);

$("#langSelect").on("change", function () {
  lang = this.value;
  document.cookie = `lang=${lang};`;
  applyTranslations(lang);
  document.body.classList.toggle("rtl", lang === "ar");
});

if (!employee) {
  document.body.innerHTML = "<h3>Employee not found.</h3>";
} else {
  document.getElementById(
    "empName"
  ).textContent = `${employee.firstName} ${employee.lastName}`;

  document.getElementById("firstName").textContent = employee.firstName;
  document.getElementById("lastName").textContent = employee.lastName;
  document.getElementById("email").textContent = employee.email;
  document.getElementById("position").textContent = employee.position;
  document.getElementById("age").textContent = employee.age;
  document.getElementById("salary").textContent = employee.salary;
  document.getElementById("joinDate").textContent = employee.joinDate;
  document.getElementById("address").textContent = employee.address;
  document.getElementById("phoneNumber").textContent = employee.phoneNumber;
}
