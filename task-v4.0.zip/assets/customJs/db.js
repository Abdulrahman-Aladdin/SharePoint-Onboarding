class Database {
  _data = [];

  constructor() {
    this._data = [
      {
        id: 1,
        firstName: "Ahmed",
        lastName: "Tamer",
        position: "Software Engineer",
        age: 22,
        email: "a@gmail.com",
        salary: 5000,
        joinDate: "2022-01-15",
        address: "123 Main St, Cityville",
        phoneNumber: "123-456-7890",
      },
      {
        id: 2,
        firstName: "Sara",
        lastName: "Ali",
        position: "Product Manager",
        age: 29,
        email: "s@gmail.com",
        salary: 6000,
        joinDate: "2021-03-22",
        address: "456 Oak St, Townsville",
        phoneNumber: "987-654-3210",
      },
      {
        id: 3,
        firstName: "Omar",
        lastName: "Hassan",
        position: "UX Designer",
        age: 31,
        email: "o@gmail.com",
        salary: 5500,
        joinDate: "2020-07-30",
        address: "789 Pine St, Villageville",
        phoneNumber: "555-123-4567",
      },
      {
        id: 4,
        firstName: "Lina",
        lastName: "Khaled",
        position: "Data Analyst",
        age: 27,
        email: "l@gmail.com",
        salary: 5200,
        joinDate: "2019-11-12",
        address: "321 Maple St, Hamletville",
        phoneNumber: "444-987-6543",
      },
    ];
  }

  getAll() {
    return [...this._data];
  }

  getById(id) {
    return this._data.find((item) => item.id === id);
  }

  create(item) {
    item.id = this._data.length + 1;
    this._data.push(item);
    return item;
  }

  update(id, updatedItem) {
    const index = this._data.findIndex((item) => item.id === id);

    if (index !== -1) {
      this._data[index] = { id, ...updatedItem };
      return this._data[index];
    }

    return null;
  }

  delete(id) {
    const index = this._data.findIndex((item) => item.id === id);
    if (index !== -1) {
      return this._data.splice(index, 1)[0];
    }
    return null;
  }
}

const db = new Database();
export default db;
