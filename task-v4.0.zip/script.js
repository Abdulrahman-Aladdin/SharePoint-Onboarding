import db from "./assets/customJs/db.js";
import translations from "./assets/customJs/i18n.js";

function applyTranslations(lang) {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    el.textContent = translations[lang][key];
  });

  if (lang === "ar") {
    document.body.setAttribute("dir", "rtl");
    document.body.classList.add("rtl");
  } else {
    document.body.setAttribute("dir", "ltr");
    document.body.classList.remove("rtl");
  }
}

function buildTable(lang) {
  if (employeeTable) {
    employeeTable.destroy();
    document.getElementById("employeesTable").innerHTML = "";
  }

  employeeTable = new DataTable($("#employeesTable"), {
    data: db.getAll(),
    language: {
      search: translations[lang]["search"],
      lengthMenu: translations[lang]["lengthMenu"],
      info: translations[lang]["info"],
      infoEmpty: translations[lang]["infoEmpty"],
      infoFiltered: translations[lang]["infoFiltered"],
      zeroRecords: translations[lang]["zeroRecords"],
      paginate: {
        first: translations[lang]["paginateFirst"],
        previous: translations[lang]["paginatePrevious"],
        next: translations[lang]["paginateNext"],
        last: translations[lang]["paginateLast"],
      },
    },
    columns: [
      { data: "firstName", title: translations[lang]["firstName"] },
      { data: "lastName", title: translations[lang]["lastName"] },
      { data: "email", title: translations[lang]["email"] },
      { data: "position", title: translations[lang]["position"] },
      { data: "age", title: translations[lang]["age"] },
      {
        data: null,
        title: translations[lang]["actions"],
        render: (data) => `
                    <button class="btn btn-warning btn-sm editBtn">${translations[lang]["edit"]}</button>
                    <button class="btn btn-danger btn-sm deleteBtn">${translations[lang]["delete"]}</button>
                    <button class="btn btn-info btn-sm view-btn" data-id="${data.id}">${translations[lang]["view"]}</button>
                `,
      },
    ],
    responsive: true,
  });
}

function refreshTable() {
  employeeTable.clear().rows.add(db.getAll()).draw();
}

function getCookie(name) {
  return document.cookie
    .split(";")
    .find((row) => row.startsWith(name + "="))
    ?.split("=")[1];
}

let lang = getCookie("lang") || "en";
let operation = "";
let employeeTable = null;
const empModal = new bootstrap.Modal($("#employeeModal"));
const confirmationModal = new bootstrap.Modal($("#deleteConfirmationModal"));

$("#langSelect").val(lang);

toastr.options = {
  closeButton: true,
  newestOnTop: false,
  progressBar: true,
  positionClass: "toast-top-right",
  preventDuplicates: true,
  onclick: null,
  showDuration: "300",
  hideDuration: "1000",
  timeOut: "3000",
  showEasing: "swing",
  hideEasing: "linear",
  showMethod: "fadeIn",
  hideMethod: "fadeOut",
};

applyTranslations(lang);
buildTable(lang);

$("#langSelect").on("change", function () {
  lang = this.value;
  document.cookie = `lang=${lang};`;
  applyTranslations(lang);
  document.body.classList.toggle("rtl", lang === "ar");
  buildTable(lang);
});

$("#addBtn").on("click", function () {
  $("#modalTitle").text(translations[lang]["addEmployee"]);

  operation = "add";

  $("#empFirstName").val("");
  $("#empLastName").val("");
  $("#empPosition").val("");
  $("#empAge").val("");
  $("#empEmail").val("");
  $("#empSalary").val("");
  $("#empJoinDate").val("");
  $("#empAddress").val("");
  $("#empPhoneNumber").val("");

  empModal.show();
});

$("#employeesTable").on("click", ".editBtn", function () {
  const row = employeeTable.row($(this).closest("tr"));
  const data = row.data();

  operation = "edit";

  $("#modalTitle").text(translations[lang]["editEmployee"]);
  $("#empId").val(data.id);
  $("#empFirstName").val(data.firstName);
  $("#empLastName").val(data.lastName);
  $("#empPosition").val(data.position);
  $("#empAge").val(data.age);
  $("#empEmail").val(data.email);
  $("#empSalary").val(data.salary);
  $("#empJoinDate").val(data.joinDate);
  $("#empAddress").val(data.address);
  $("#empPhoneNumber").val(data.phoneNumber);

  empModal.show();
});

$("#btnSave").on("click", function () {
  const form = $("#empForm")[0];
  if (!form.checkValidity()) {
    form.classList.add("was-validated");
    return;
  }

  const employee = {
    firstName: $("#empFirstName").val(),
    lastName: $("#empLastName").val(),
    position: $("#empPosition").val(),
    age: $("#empAge").val(),
    email: $("#empEmail").val(),
    salary: $("#empSalary").val(),
    joinDate: $("#empJoinDate").val(),
    address: $("#empAddress").val(),
    phoneNumber: $("#empPhoneNumber").val(),
  };

  if (operation === "edit") {
    db.update(parseInt($("#empId").val()), employee);
    toastr.success(translations[lang]["employeeUpdated"]);
  } else if (operation === "add") {
    db.create(employee);
    toastr.success(translations[lang]["employeeAdded"]);
  }

  operation = "";

  document.activeElement.blur();

  refreshTable();
  empModal.hide();
});

$("#employeesTable").on("click", ".deleteBtn", function () {
  const row = employeeTable.row($(this).closest("tr"));
  const data = row.data();

  $("#confirmationMessageTag").text(translations[lang]["deleteConfirmation"]);

  $("#btnConfirmDelete")
    .off("click")
    .on("click", function () {
      db.delete(data.id);
      refreshTable();
      // Display an info toast with no title
      toastr.success(translations[lang]["employeeDeleted"]);
      document.activeElement.blur();
      confirmationModal.hide();
    });

  confirmationModal.show();
});

$("#employeesTable").on("click", ".view-btn", function () {
  const id = $(this).data("id");
  window.location.href = `details.html?id=${id}`;
});
