let employees = [
  {
    id: 1,
    firstName: "Ahmed",
    lastName: "Tamer",
    position: "Software Engineer",
    age: 22,
    email: "a@gmail.com",
  },
  {
    id: 2,
    firstName: "Sara",
    lastName: "Ali",
    position: "Product Manager",
    age: 29,
    email: "s@gmail.com",
  },
  {
    id: 3,
    firstName: "Omar",
    lastName: "Hassan",
    position: "UX Designer",
    age: 31,
    email: "o@gmail.com",
  },
  {
    id: 4,
    firstName: "Lina",
    lastName: "Khaled",
    position: "Data Analyst",
    age: 27,
    email: "l@gmail.com",
  },
];

const translations = {
  en: {
    addEmployee: "Add Employee",
    firstName: "First Name",
    lastName: "Last Name",
    position: "Position",
    age: "Age",
    email: "Email",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    confirmDelete: "Delete Confirmation",
  },
  ar: {
    addEmployee: "إضافة موظف",
    firstName: "الاسم الأول",
    lastName: "اسم العائلة",
    position: "الوظيفة",
    age: "العمر",
    email: "البريد الإلكتروني",
    save: "حفظ",
    cancel: "إلغاء",
    delete: "حذف",
    confirmDelete: "تأكيد الحذف",
  },
};

let lang = "en";

function applyTranslations(lang) {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    el.textContent = translations[lang][key];
  });

  if (lang === "ar") {
    document.body.setAttribute("dir", "rtl");
    document.body.classList.add("rtl");
  } else {
    document.body.setAttribute("dir", "ltr");
    document.body.classList.remove("rtl");
  }
}

applyTranslations("en");

document.getElementById("langSelect").addEventListener("change", function () {
  lang = this.value;
  applyTranslations(lang);
  document.body.classList.toggle("rtl", lang === "ar");
  buildTable(lang, employees);
});

const columns_en = [
  { data: "firstName", title: "First Name" },
  { data: "lastName", title: "Last Name" },
  { data: "email", title: "Email" },
  { data: "position", title: "Position" },
  { data: "age", title: "Age" },
];

const columns_ar = [
  { data: "firstName", title: "الاسم الأول" },
  { data: "lastName", title: "اسم العائلة" },
  { data: "email", title: "البريد الإلكتروني" },
  { data: "position", title: "الوظيفة" },
  { data: "age", title: "العمر" },
];

let employeeTable = null;

function buildTable(lang) {
  if (employeeTable) {
    employeeTable.destroy();
    document.getElementById("employeesTable").innerHTML = "";
  }

  let editButtonText = lang === "en" ? "Edit" : "تعديل";
  let deleteButtonText = lang === "en" ? "Delete" : "حذف";

  employeeTable = new DataTable($("#employeesTable"), {
    data: employees,
    language: {
      search: lang === "en" ? "Search:" : "بحث:",
      lengthMenu: lang === "en" ? "Show _MENU_ entries" : "عرض _MENU_ مدخلات",
      info:
        lang === "en"
          ? "Showing _START_ to _END_ of _TOTAL_ entries"
          : "عرض _START_ إلى _END_ من أصل _TOTAL_ مدخلات",
      infoEmpty:
        lang === "en" ? "No entries available" : "لا توجد مدخلات متاحة",
      infoFiltered:
        lang === "en"
          ? "(filtered from _MAX_ total entries)"
          : "(تم التصفية من أصل _MAX_ مدخلات)",
      zeroRecords:
        lang === "en"
          ? "No matching records found"
          : "لم يتم العثور على سجلات مطابقة",
      paginate: {
        first: lang === "en" ? "First" : "الأول",
        previous: lang === "en" ? "Previous" : "السابق",
        next: lang === "en" ? "Next" : "التالي",
        last: lang === "en" ? "Last" : "الأخير",
      },
    },
    columns: [
      ...(lang === "en" ? columns_en : columns_ar),
      {
        data: null,
        title: lang === "en" ? "Actions" : "إجراءات",
        render: () => `
                    <button class="btn btn-warning btn-sm editBtn">${editButtonText}</button>
                    <button class="btn btn-danger btn-sm deleteBtn">${deleteButtonText}</button>
                `,
      },
    ],
    responsive: true,
  });
}

buildTable("en", employees);

const empModal = new bootstrap.Modal($("#employeeModal"));
const confirmationModal = new bootstrap.Modal($("#deleteConfirmationModal"));

toastr.options = {
  closeButton: true,
  newestOnTop: false,
  progressBar: true,
  positionClass: "toast-top-right",
  preventDuplicates: true,
  onclick: null,
  showDuration: "300",
  hideDuration: "1000",
  timeOut: "3000",
  showEasing: "swing",
  hideEasing: "linear",
  showMethod: "fadeIn",
  hideMethod: "fadeOut",
};

let table = new DataTable($("#employeesTable"), {
  data: employees,
  columns: [
    { data: "firstName", title: "First Name" },
    { data: "lastName", title: "Last Name" },
    { data: "email", title: "Email" },
    { data: "position", title: "Position" },
    { data: "age", title: "Age" },
    {
      data: null,
      render: () => `
                    <button class="btn btn-warning btn-sm editBtn">Edit</button>
                    <button class="btn btn-danger btn-sm deleteBtn">Delete</button>
                `,
    },
  ],
  responsive: true,
});

function refreshTable() {
  employeeTable.clear().rows.add(employees).draw();
}

$("#addBtn").on("click", function () {
  $("#modalTitle").text(lang === "en" ? "Add Employee" : "إضافة موظف");

  $("#empIndex").val("");
  $("#empId").val("");
  $("#empFirstName").val("");
  $("#empLastName").val("");
  $("#empPosition").val("");
  $("#empAge").val("");
  $("#empEmail").val("");

  empModal.show();
});

$("#employeesTable").on("click", ".editBtn", function () {
  const row = employeeTable.row($(this).closest("tr"));
  const data = row.data();

  const index = employees.findIndex((emp) => emp.id == data.id);

  $("#modalTitle").text(lang === "en" ? "Edit Employee" : "تعديل موظف");
  $("#empIndex").val(index);
  $("#empId").val(data.id);

  $("#empFirstName").val(data.firstName);
  $("#empLastName").val(data.lastName);
  $("#empPosition").val(data.position);
  $("#empAge").val(data.age);
  $("#empEmail").val(data.email);

  empModal.show();
});

$("#btnSave").on("click", function () {
  const form = $("#empForm")[0];
  if (!form.checkValidity()) {
    form.classList.add("was-validated");
    return;
  }

  const index = $("#empIndex").val();
  const id = $("#empId").val() || Date.now();

  const employee = {
    id,
    firstName: $("#empFirstName").val(),
    lastName: $("#empLastName").val(),
    position: $("#empPosition").val(),
    age: $("#empAge").val(),
    email: $("#empEmail").val(),
  };

  if (index) {
    employees[index] = employee;
    toastr.success(
      lang === "en"
        ? "Employee updated successfully."
        : "تم تحديث بيانات الموظف بنجاح."
    );
  } else {
    employees.push(employee);
    toastr.success(
      lang === "en"
        ? "Employee added successfully."
        : "تم إضافة موظف جديد بنجاح."
    );
  }

  refreshTable();
  empModal.hide();
});

$("#employeesTable").on("click", ".deleteBtn", function () {
  const row = employeeTable.row($(this).closest("tr"));
  const data = row.data();

    $("#confirmationMessageTag").text(
        lang === "en"
            ? `Are you sure you want to delete ${data.firstName} ${data.lastName}?`
            : `هل أنت متأكد أنك تريد حذف هذا الموظف؟`
  );

  $("#btnConfirmDelete")
    .off("click")
    .on("click", function () {
      employees = employees.filter((emp) => emp.id !== data.id);
      refreshTable();
      // Display an info toast with no title
      toastr.success(
        lang === "en"
          ? "Employee deleted successfully."
          : "تم حذف الموظف بنجاح."
      );
      confirmationModal.hide();
    });

  confirmationModal.show();
});
