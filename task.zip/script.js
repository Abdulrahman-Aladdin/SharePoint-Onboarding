let employees = [
    { id: 1, firstName: 'Ahmed', lastName: 'Tamer', position: 'Software Engineer', age: 22, email: 'a@gmail.com' },
    { id: 2, firstName: 'Sara', lastName: 'Ali', position: 'Product Manager', age: 29, email: 's@gmail.com' },
    { id: 3, firstName: 'Omar', lastName: 'Hassan', position: 'UX Designer', age: 31, email: 'o@gmail.com' },
    { id: 4, firstName: 'Lina', lastName: 'Khaled', position: 'Data Analyst', age: 27, email: 'l@gmail.com' }
]

const modal = new bootstrap.Modal(document.getElementById('employeeModal'));

let table = new DataTable($('#employeesTable'), {
    data: employees,
    columns: [
        { data: 'firstName', title: 'First Name' },
        { data: 'lastName', title: 'Last Name' },
        { data: 'position', title: 'Position' },
        { data: 'age', title: 'Age' },
        { data: 'email', title: 'Email' },
        {
            data: null,
            render: () => `
                    <button class="btn btn-warning btn-sm editBtn">Edit</button>
                    <button class="btn btn-danger btn-sm deleteBtn">Delete</button>
                `
        }
    ],
    responsive: true
});

function refreshTable() { 
    table.clear().rows.add(employees).draw();
}

$('#addBtn').on('click', function () {
    $('#modalTitle').text("Add Employee");

    $('#empIndex').val("");
    $('#empId').val("");
    $('#empFirstName').val("");
    $('#empLastName').val("");
    $('#empPosition').val("");
    $('#empAge').val("");
    $('#empEmail').val("");

    modal.show();
});

$('#employeesTable').on('click', '.editBtn', function () {

    const row = table.row($(this).closest('tr'));
    const data = row.data();

    const index = employees.findIndex(emp => emp.id == data.id);

    $('#modalTitle').text("Edit Employee");
    $('#empIndex').val(index);
    $('#empId').val(data.id);

    $('#empFirstName').val(data.firstName);
    $('#empLastName').val(data.lastName);
    $('#empPosition').val(data.position);
    $('#empAge').val(data.age);
    $('#empEmail').val(data.email);

    modal.show();
});

$('#btnSave').on('click', function () {

    const index = $('#empIndex').val();
    const id = $('#empId').val() || Date.now();

    const employee = {
        id,
        firstName: $('#empFirstName').val(),
        lastName: $('#empLastName').val(),
        position: $('#empPosition').val(),
        age: $('#empAge').val(),
        email: $('#empEmail').val()
    };

    if (index) {
        employees[index] = employee;
    } else {
        employees.push(employee);
    }

    refreshTable();
    modal.hide();
});

$('#employeesTable').on('click', '.deleteBtn', function () {

    const row = table.row($(this).closest('tr'));
    const data = row.data();

    if (confirm(`Are you sure you want to delete ${data.firstName} ${data.lastName}?`)) {
        employees = employees.filter(emp => emp.id !== data.id);
        refreshTable();
    }
});
